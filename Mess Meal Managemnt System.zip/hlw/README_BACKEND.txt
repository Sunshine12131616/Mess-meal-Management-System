Mess Meal Management System - Backend + Database Version

Files:
- index.html = frontend page structure
- style.css = frontend design
- script.js = frontend logic and API calls
- server.js = Node.js backend server
- package.json = start command
- start.bat = easy Windows double-click start file
- mess_data.sqlite = SQLite database file, created automatically after server starts

How to run:
1. Double-click start.bat
2. Keep the black terminal window open
3. Browser will open at http://localhost:3000
4. Use the website normally

Alternative run:
1. Open terminal in this folder
2. Run: npm start
3. Open: http://localhost:3000

Important:
- Do not open index.html directly for the database version.
- Use http://localhost:3000 so data saves into SQLite database.
- If you close the terminal window, the backend server stops.

Database:
- Data is saved in mess_data.sqlite
- This file is created automatically by server.js
