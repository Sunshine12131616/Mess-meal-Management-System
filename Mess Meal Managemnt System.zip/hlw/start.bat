@echo off
title Mess Meal Management System
echo Starting Mess Meal Management System...
echo.
echo Browser will open at http://localhost:3000
echo Keep this window open while using the app.
echo.
start "" http://localhost:3000
node server.js
pause
