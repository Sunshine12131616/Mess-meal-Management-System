const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const PORT = 3000;
const ROOT = __dirname;
const DB_PATH = path.join(ROOT, "mess_data.sqlite");

const defaultData = {
  members: [],
  meals: [],
  expenses: [],
  stocks: [],
  stockUses: [],
  buaBills: [],
  otherExpenses: [],
  deposits: []
};

const db = new DatabaseSync(DB_PATH);
db.exec(`
  CREATE TABLE IF NOT EXISTS app_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    data TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )
`);

const insertState = db.prepare(`
  INSERT OR IGNORE INTO app_state (id, data, updated_at)
  VALUES (1, ?, datetime('now'))
`);
const readState = db.prepare("SELECT data FROM app_state WHERE id = 1");
const updateState = db.prepare("UPDATE app_state SET data = ?, updated_at = datetime('now') WHERE id = 1");

insertState.run(JSON.stringify(defaultData));

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".pdf": "application/pdf"
};

function sendJson(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(body));
}

function readRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 10 * 1024 * 1024) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function serveFile(req, res) {
  const requestUrl = new URL(req.url, `http://${req.headers.host}`);
  const safePath = requestUrl.pathname === "/" ? "/index.html" : requestUrl.pathname;
  const decodedPath = decodeURIComponent(safePath);
  const filePath = path.normalize(path.join(ROOT, decodedPath));
  const ext = path.extname(filePath).toLowerCase();

  if (!filePath.startsWith(ROOT) || ext === ".sqlite" || ext === ".db") {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, content) => {
    if (error) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("File not found");
      return;
    }

    res.writeHead(200, { "Content-Type": mimeTypes[ext] || "application/octet-stream" });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.url === "/api/data" && req.method === "GET") {
    const row = readState.get();
    sendJson(res, 200, JSON.parse(row.data));
    return;
  }

  if (req.url === "/api/data" && req.method === "POST") {
    try {
      const body = await readRequestBody(req);
      const parsed = JSON.parse(body);
      const cleanData = { ...defaultData, ...parsed };
      updateState.run(JSON.stringify(cleanData));
      sendJson(res, 200, { success: true });
    } catch (error) {
      sendJson(res, 400, { success: false, message: "Invalid data" });
    }
    return;
  }

  if (req.method === "GET") {
    serveFile(req, res);
    return;
  }

  res.writeHead(405, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Method not allowed");
});

server.listen(PORT, () => {
  console.log(`Mess Meal Management System running at http://localhost:${PORT}`);
  console.log(`SQLite database: ${DB_PATH}`);
});
