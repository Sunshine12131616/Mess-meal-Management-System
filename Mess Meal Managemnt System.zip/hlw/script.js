const STORAGE_KEY = "messMealManagementDataV1";
const API_URL = "/api/data";

const defaultData = {
  members: [],
  meals: [],
  expenses: [],
  stocks: [],
  stockUses: [],
  buaBills: [],
  otherExpenses: [],
  deposits: []
};

let data = structuredClone(defaultData);
let usingBackend = false;

const $ = (id) => document.getElementById(id);
const today = () => new Date().toISOString().slice(0, 10);
const currentMonth = () => new Date().toISOString().slice(0, 7);
const money = (value) => `Tk ${Number(value || 0).toFixed(2)}`;
const number = (value) => Number(value || 0);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);

async function loadData() {
  if (location.protocol !== "file:") {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error("Backend did not respond");
      const serverData = await response.json();
      usingBackend = true;
      return { ...structuredClone(defaultData), ...serverData };
    } catch (error) {
      console.warn("Backend data load failed. Falling back to browser localStorage.", error);
    }
  }

  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) return structuredClone(defaultData);
  try {
    return { ...structuredClone(defaultData), ...JSON.parse(saved) };
  } catch (error) {
    alert("Saved data could not be loaded. Starting with empty data.");
    return structuredClone(defaultData);
  }
}

function saveData() {
  if (usingBackend) {
    return fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    }).catch((error) => {
      console.error("Database save failed.", error);
      alert("Database save failed. Please check if the server is running.");
    });
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  return Promise.resolve();
}

function selectedMonth() {
  return $("monthFilter").value || currentMonth();
}

function isInSelectedMonth(dateValue) {
  return String(dateValue || "").slice(0, 7) === selectedMonth();
}

function getMemberName(memberId) {
  const member = data.members.find((item) => item.id === memberId);
  return member ? member.name : "Unknown";
}

function activeMembers() {
  return data.members.filter((member) => member.active);
}

function totalMealOf(entry) {
  return number(entry.breakfast) + number(entry.lunch) + number(entry.dinner);
}

function monthlyMeals() {
  return data.meals.filter((meal) => isInSelectedMonth(meal.date));
}

function monthlyExpenses() {
  return data.expenses.filter((expense) => isInSelectedMonth(expense.date));
}

function monthlyDeposits() {
  return data.deposits.filter((deposit) => isInSelectedMonth(deposit.date));
}

function monthlyOtherExpenses() {
  return data.otherExpenses.filter((expense) => isInSelectedMonth(expense.date));
}

function monthTotals() {
  const meals = monthlyMeals();
  const expenses = monthlyExpenses();
  const deposits = monthlyDeposits();
  const otherExpenses = monthlyOtherExpenses();
  const totalMeals = meals.reduce((sum, meal) => sum + totalMealOf(meal), 0);
  const totalExpense = expenses.reduce((sum, expense) => sum + number(expense.amount), 0);
  const totalDeposit = deposits.reduce((sum, deposit) => sum + number(deposit.amount), 0);
  const totalOtherExpense = otherExpenses.reduce((sum, expense) => sum + number(expense.amount), 0);
  const buaBill = getCurrentBuaBill();
  const mealRate = totalMeals > 0 ? totalExpense / totalMeals : 0;
  return { meals, expenses, deposits, otherExpenses, totalMeals, totalExpense, totalDeposit, totalOtherExpense, buaBill, mealRate };
}

function getCurrentBuaBill() {
  return data.buaBills.find((bill) => bill.month === selectedMonth()) || { amount: 0, note: "" };
}

function calculateMemberBills() {
  const totals = monthTotals();
  const active = activeMembers();
  const buaShare = active.length ? number(totals.buaBill.amount) / active.length : 0;
  const otherShare = active.length ? number(totals.totalOtherExpense) / active.length : 0;

  return data.members.map((member) => {
    const memberMeals = totals.meals
      .filter((meal) => meal.memberId === member.id)
      .reduce((sum, meal) => sum + totalMealOf(meal), 0);
    const mealCost = memberMeals * totals.mealRate;
    const deposit = totals.deposits
      .filter((item) => item.memberId === member.id)
      .reduce((sum, item) => sum + number(item.amount), 0);
    const memberBuaShare = member.active ? buaShare : 0;
    const otherExpense = member.active ? otherShare : 0;
    const totalCost = mealCost + memberBuaShare + otherExpense;
    const balance = totalCost - deposit;
    return { member, memberMeals, mealCost, buaShare: memberBuaShare, otherExpense, deposit, totalCost, balance };
  });
}

function stockSummary() {
  const map = {};

  data.stocks.forEach((stock) => {
    const key = stock.item.trim().toLowerCase();
    if (!map[key]) {
      map[key] = { item: stock.item.trim(), quantity: 0, unit: stock.unit, price: 0 };
    }
    map[key].quantity += number(stock.quantity);
    map[key].price += number(stock.price);
    map[key].unit = stock.unit || map[key].unit;
  });

  data.stockUses.forEach((use) => {
    const key = use.item.trim().toLowerCase();
    if (!map[key]) {
      map[key] = { item: use.item.trim(), quantity: 0, unit: "", price: 0 };
    }
    map[key].quantity -= number(use.quantity);
  });

  return Object.values(map).sort((a, b) => a.item.localeCompare(b.item));
}

function renderAll() {
  renderMemberOptions();
  renderDashboard();
  renderMembers();
  renderMeals();
  renderExpenses();
  renderStocks();
  renderBua();
  renderOtherExpenses();
  renderDeposits();
  renderBill();
}

function renderDashboard() {
  const totals = monthTotals();
  const bills = calculateMemberBills();
  const grandExpense = totals.totalExpense + totals.totalOtherExpense + number(totals.buaBill.amount);
  const due = bills.reduce((sum, bill) => sum + Math.max(bill.balance, 0), 0);
  const advance = bills.reduce((sum, bill) => sum + Math.max(-bill.balance, 0), 0);
  const lows = stockSummary().filter((stock) => stock.quantity < 2);
  const collectionPercent = grandExpense > 0 ? Math.min((totals.totalDeposit / grandExpense) * 100, 100) : 0;

  $("dashboardHero").innerHTML = `
    <div class="hero-copy">
      <span class="dashboard-chip">${selectedMonth()}</span>
      <h2>Monthly Snapshot</h2>
      <p>Quick view of meals, expenses, deposits, due and advance for this month.</p>
      <div class="hero-main-number">
        <span>Total Meals</span>
        <strong>${totals.totalMeals}</strong>
      </div>
    </div>
    <div class="hero-meter" style="--progress:${collectionPercent * 3.6}deg">
      <div class="meter-ring">
        <span>${collectionPercent.toFixed(0)}%</span>
        <small>Deposit</small>
      </div>
    </div>
    <div class="hero-mini-grid">
      <div><span>Meal Rate</span><strong>${money(totals.mealRate)}</strong></div>
      <div><span>Grand Expense</span><strong>${money(grandExpense)}</strong></div>
      <div><span>Total Deposit</span><strong>${money(totals.totalDeposit)}</strong></div>
      <div><span>Active Members</span><strong>${activeMembers().length}</strong></div>
    </div>
  `;

  const cards = [
    { label: "Members", value: data.members.length, tone: "members" },
    { label: "Bazar", value: money(totals.totalExpense), tone: "expense" },
    { label: "Bua Bill", value: money(totals.buaBill.amount), tone: "rate" },
    { label: "Other Exp.", value: money(totals.totalOtherExpense), tone: "meal" },
    { label: "Due", value: money(due), tone: "due" },
    { label: "Advance", value: money(advance), tone: "advance" }
  ];

  $("dashboardCards").innerHTML = cards.map((card) => `
    <article class="dashboard-kpi ${card.tone}">
      <div>
        <span>${card.label}</span>
        <strong>${card.value}</strong>
      </div>
    </article>
  `).join("");

  $("lowStockList").innerHTML = lows.length
    ? lows.map((stock) => `
      <div class="stock-radar-item">
        <div>
          <strong>${stock.item}</strong>
          <span>${stock.quantity <= 0 ? "Out of Stock" : `${stock.quantity.toFixed(2)} ${stock.unit || "unit"} left`}</span>
        </div>
        <span class="badge ${stock.quantity <= 0 ? "out" : "low"}">${stock.quantity <= 0 ? "Out" : "Low"}</span>
      </div>
    `).join("")
    : `<div class="empty-state">No low stock alerts.</div>`;

  $("dashboardDueRows").innerHTML = bills.length
    ? bills.map((bill) => `
      <div class="member-balance-card ${bill.balance > 0 ? "has-due" : bill.balance < 0 ? "has-advance" : "settled"}">
        <div class="member-balance-info">
          <strong>${bill.member.name}</strong>
          <span>${bill.memberMeals} meals this month</span>
        </div>
        <div class="member-balance-money">
          ${bill.balance > 0 ? `<span class="badge due">Due ${money(bill.balance)}</span>` : ""}
          ${bill.balance < 0 ? `<span class="badge advance">Advance ${money(Math.abs(bill.balance))}</span>` : ""}
          ${Math.abs(bill.balance) < 0.01 ? `<span class="badge">Settled</span>` : ""}
        </div>
      </div>
    `).join("")
    : `<div class="empty-state">No members yet.</div>`;
}

function renderMemberOptions() {
  const options = activeMembers().map((member) => `<option value="${member.id}">${member.name}</option>`).join("");
  $("mealMember").innerHTML = options || `<option value="">Add active member first</option>`;
  $("depositMember").innerHTML = options || `<option value="">Add active member first</option>`;

  const stockOptions = stockSummary().map((stock) => {
    const label = stock.quantity <= 0 ? "Out of Stock" : `${stock.quantity.toFixed(2)} ${stock.unit || "unit"}`;
    return `<option value="${stock.item}">${stock.item} (${label})</option>`;
  }).join("");
  $("useStockItem").innerHTML = stockOptions || `<option value="">Add stock first</option>`;
}

function renderMembers() {
  $("memberRows").innerHTML = data.members.length
    ? data.members.map((member) => `
      <tr>
        <td>${member.name}</td>
        <td>${member.phone || "-"}</td>
        <td><span class="badge ${member.active ? "" : "inactive"}">${member.active ? "Active" : "Inactive"}</span></td>
        <td>
          <button class="small-btn" onclick="editMember('${member.id}')">Edit</button>
          <button class="small-btn delete" onclick="deleteMember('${member.id}')">Delete</button>
        </td>
      </tr>
    `).join("")
    : `<tr><td colspan="4" class="empty-state">No members added yet.</td></tr>`;
}

function renderMeals() {
  const meals = monthlyMeals().sort((a, b) => b.date.localeCompare(a.date));
  const total = meals.reduce((sum, meal) => sum + totalMealOf(meal), 0);
  $("mealTotalLabel").textContent = `Total: ${total}`;
  $("mealRows").innerHTML = meals.length
    ? meals.map((meal) => `
      <tr>
        <td>${meal.date}</td>
        <td>${getMemberName(meal.memberId)}</td>
        <td>${meal.breakfast}</td>
        <td>${meal.lunch}</td>
        <td>${meal.dinner}</td>
        <td>${totalMealOf(meal)}</td>
        <td>
          <button class="small-btn" onclick="editMeal('${meal.id}')">Edit</button>
          <button class="small-btn delete" onclick="deleteMeal('${meal.id}')">Delete</button>
        </td>
      </tr>
    `).join("")
    : `<tr><td colspan="7" class="empty-state">No meal entries for this month.</td></tr>`;
}

function renderExpenses() {
  const expenses = monthlyExpenses().sort((a, b) => b.date.localeCompare(a.date));
  const total = expenses.reduce((sum, expense) => sum + number(expense.amount), 0);
  $("expenseTotalLabel").textContent = `Total: ${money(total)}`;
  $("expenseRows").innerHTML = expenses.length
    ? expenses.map((expense) => `
      <tr>
        <td>${expense.date}</td>
        <td>${expense.buyer}</td>
        <td>${expense.item}</td>
        <td>${money(expense.amount)}</td>
        <td>${expense.note || "-"}</td>
        <td>
          <button class="small-btn" onclick="editExpense('${expense.id}')">Edit</button>
          <button class="small-btn delete" onclick="deleteExpense('${expense.id}')">Delete</button>
        </td>
      </tr>
    `).join("")
    : `<tr><td colspan="6" class="empty-state">No expenses for this month.</td></tr>`;
}

function renderStocks() {
  const stocks = stockSummary();
  $("stockRows").innerHTML = stocks.length
    ? stocks.map((stock) => {
      const isOut = stock.quantity <= 0;
      const isLow = stock.quantity > 0 && stock.quantity < 2;
      return `
        <tr>
          <td>${stock.item}</td>
          <td>${isOut ? `<span class="badge out">Out of Stock</span>` : stock.quantity.toFixed(2)}</td>
          <td>${stock.unit || "-"}</td>
          <td>${money(stock.price)}</td>
          <td><span class="badge ${isOut ? "out" : isLow ? "low" : ""}">${isOut ? "Out of Stock" : isLow ? "Low Stock" : "OK"}</span></td>
          <td><button class="small-btn delete" onclick="deleteStockItem('${stock.item}')">Delete Item</button></td>
        </tr>
      `;
    }).join("")
    : `<tr><td colspan="6" class="empty-state">No stock added yet.</td></tr>`;

  const uses = data.stockUses.filter((use) => isInSelectedMonth(use.date)).sort((a, b) => b.date.localeCompare(a.date));
  $("stockUseRows").innerHTML = uses.length
    ? uses.map((use) => `
      <tr>
        <td>${use.date}</td>
        <td>${use.item}</td>
        <td>${use.quantity}</td>
        <td>${use.note || "-"}</td>
        <td><button class="small-btn delete" onclick="deleteStockUse('${use.id}')">Delete</button></td>
      </tr>
    `).join("")
    : `<tr><td colspan="5" class="empty-state">No stock usage this month.</td></tr>`;
}

function renderBua() {
  const bill = getCurrentBuaBill();
  $("buaMonth").value = selectedMonth();
  $("buaAmount").value = bill.amount || "";
  $("buaNote").value = bill.note || "";

  const activeCount = activeMembers().length;
  const share = activeCount ? number(bill.amount) / activeCount : 0;
  $("buaShareLabel").textContent = `Share: ${money(share)}`;
  $("buaRows").innerHTML = data.members.length
    ? data.members.map((member) => `
      <tr>
        <td>${member.name}</td>
        <td><span class="badge ${member.active ? "" : "inactive"}">${member.active ? "Active" : "Inactive"}</span></td>
        <td>${member.active ? money(share) : money(0)}</td>
      </tr>
    `).join("")
    : `<tr><td colspan="3" class="empty-state">No members yet.</td></tr>`;
}

function renderDeposits() {
  const deposits = monthlyDeposits().sort((a, b) => b.date.localeCompare(a.date));
  const total = deposits.reduce((sum, deposit) => sum + number(deposit.amount), 0);
  $("depositTotalLabel").textContent = `Total: ${money(total)}`;
  $("depositRows").innerHTML = deposits.length
    ? deposits.map((deposit) => `
      <tr>
        <td>${deposit.date}</td>
        <td>${getMemberName(deposit.memberId)}</td>
        <td>${money(deposit.amount)}</td>
        <td>${deposit.note || "-"}</td>
        <td>
          <button class="small-btn" onclick="editDeposit('${deposit.id}')">Edit</button>
          <button class="small-btn delete" onclick="deleteDeposit('${deposit.id}')">Delete</button>
        </td>
      </tr>
    `).join("")
    : `<tr><td colspan="5" class="empty-state">No deposits for this month.</td></tr>`;
}

function renderOtherExpenses() {
  const expenses = monthlyOtherExpenses().sort((a, b) => b.date.localeCompare(a.date));
  const total = expenses.reduce((sum, expense) => sum + number(expense.amount), 0);
  $("otherTotalLabel").textContent = `Total: ${money(total)}`;
  $("otherRows").innerHTML = expenses.length
    ? expenses.map((expense) => `
      <tr>
        <td>${expense.date}</td>
        <td>${expense.name}</td>
        <td>${money(expense.amount)}</td>
        <td>${expense.note || "-"}</td>
        <td>
          <button class="small-btn" onclick="editOtherExpense('${expense.id}')">Edit</button>
          <button class="small-btn delete" onclick="deleteOtherExpense('${expense.id}')">Delete</button>
        </td>
      </tr>
    `).join("")
    : `<tr><td colspan="5" class="empty-state">No other expenses for this month.</td></tr>`;
}

function renderBill() {
  const totals = monthTotals();
  const activeCount = activeMembers().length;
  const buaShare = activeCount ? number(totals.buaBill.amount) / activeCount : 0;
  const otherShare = activeCount ? totals.totalOtherExpense / activeCount : 0;
  $("billMonthLabel").textContent = selectedMonth();
  $("billStats").innerHTML = [
    ["Total Meal", totals.totalMeals],
    ["Total Bazar", money(totals.totalExpense)],
    ["Meal Rate", money(totals.mealRate)],
    ["Bua Bill", money(totals.buaBill.amount)],
    ["Bua Share", money(buaShare)],
    ["Other Expense", money(totals.totalOtherExpense)],
    ["Other Share", money(otherShare)]
  ].map(([label, value]) => `<div class="bill-stat"><span>${label}</span><strong>${value}</strong></div>`).join("");

  const bills = calculateMemberBills();
  $("billRows").innerHTML = bills.length
    ? bills.map((bill) => {
      const finalText = bill.balance > 0
        ? `<span class="badge due">Due ${money(bill.balance)}</span>`
        : `<span class="badge advance">Advance ${money(Math.abs(bill.balance))}</span>`;
      return `
        <tr>
          <td>${bill.member.name}</td>
          <td>${bill.memberMeals}</td>
          <td>${money(bill.mealCost)}</td>
          <td>${money(bill.buaShare)}</td>
          <td>${money(bill.otherExpense)}</td>
          <td>${money(bill.deposit)}</td>
          <td>${Math.abs(bill.balance) < 0.01 ? money(0) : finalText}</td>
        </tr>
      `;
    }).join("")
    : `<tr><td colspan="7" class="empty-state">No members yet.</td></tr>`;
}

function resetForms() {
  ["memberForm", "mealForm", "expenseForm", "stockForm", "depositForm", "otherForm"].forEach((formId) => $(formId).reset());
  $("memberId").value = "";
  $("mealId").value = "";
  $("expenseId").value = "";
  $("stockId").value = "";
  $("depositId").value = "";
  $("otherId").value = "";
  setDefaultDates();
}

function setDefaultDates() {
  $("mealDate").value = today();
  $("expenseDate").value = today();
  $("stockDate").value = today();
  $("useStockDate").value = today();
  $("depositDate").value = today();
  $("otherDate").value = today();
}

function editMember(id) {
  const member = data.members.find((item) => item.id === id);
  if (!member) return;
  $("memberId").value = member.id;
  $("memberName").value = member.name;
  $("memberPhone").value = member.phone || "";
  $("memberActive").value = String(member.active);
  openTab("members");
}

function deleteMember(id) {
  if (!confirm("Delete this member? Related meals and deposits will stay for history.")) return;
  data.members = data.members.filter((member) => member.id !== id);
  saveData();
  renderAll();
}

function editMeal(id) {
  const meal = data.meals.find((item) => item.id === id);
  if (!meal) return;
  $("mealId").value = meal.id;
  $("mealDate").value = meal.date;
  $("mealMember").value = meal.memberId;
  $("mealBreakfast").value = meal.breakfast;
  $("mealLunch").value = meal.lunch;
  $("mealDinner").value = meal.dinner;
  openTab("meals");
}

function deleteMeal(id) {
  if (!confirm("Delete this meal entry?")) return;
  data.meals = data.meals.filter((meal) => meal.id !== id);
  saveData();
  renderAll();
}

function editExpense(id) {
  const expense = data.expenses.find((item) => item.id === id);
  if (!expense) return;
  $("expenseId").value = expense.id;
  $("expenseDate").value = expense.date;
  $("expenseBuyer").value = expense.buyer;
  $("expenseItem").value = expense.item;
  $("expenseAmount").value = expense.amount;
  $("expenseNote").value = expense.note || "";
  openTab("expenses");
}

function deleteExpense(id) {
  if (!confirm("Delete this expense?")) return;
  data.expenses = data.expenses.filter((expense) => expense.id !== id);
  saveData();
  renderAll();
}

function deleteStockItem(item) {
  if (!confirm(`Delete all stock records for ${item}?`)) return;
  const key = item.trim().toLowerCase();
  data.stocks = data.stocks.filter((stock) => stock.item.trim().toLowerCase() !== key);
  data.stockUses = data.stockUses.filter((use) => use.item.trim().toLowerCase() !== key);
  saveData();
  renderAll();
}

function deleteStockUse(id) {
  if (!confirm("Delete this stock usage entry? Stock will be added back automatically.")) return;
  data.stockUses = data.stockUses.filter((use) => use.id !== id);
  saveData();
  renderAll();
}

function editDeposit(id) {
  const deposit = data.deposits.find((item) => item.id === id);
  if (!deposit) return;
  $("depositId").value = deposit.id;
  $("depositDate").value = deposit.date;
  $("depositMember").value = deposit.memberId;
  $("depositAmount").value = deposit.amount;
  $("depositNote").value = deposit.note || "";
  openTab("deposits");
}

function editOtherExpense(id) {
  const expense = data.otherExpenses.find((item) => item.id === id);
  if (!expense) return;
  $("otherId").value = expense.id;
  $("otherDate").value = expense.date;
  $("otherName").value = expense.name;
  $("otherAmount").value = expense.amount;
  $("otherNote").value = expense.note || "";
  openTab("other");
}

function deleteOtherExpense(id) {
  if (!confirm("Delete this other expense?")) return;
  data.otherExpenses = data.otherExpenses.filter((expense) => expense.id !== id);
  saveData();
  renderAll();
}

function deleteDeposit(id) {
  if (!confirm("Delete this deposit?")) return;
  data.deposits = data.deposits.filter((deposit) => deposit.id !== id);
  saveData();
  renderAll();
}

function openTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach((button) => button.classList.toggle("active", button.dataset.tab === tabId));
  document.querySelectorAll(".tab-panel").forEach((panel) => panel.classList.toggle("active", panel.id === tabId));
}

document.querySelectorAll(".tab-btn").forEach((button) => {
  button.addEventListener("click", () => openTab(button.dataset.tab));
});

document.querySelectorAll("select").forEach((select) => {
  select.addEventListener("change", () => {
    select.classList.remove("choice-pop");
    void select.offsetWidth;
    select.classList.add("choice-pop");
    setTimeout(() => select.classList.remove("choice-pop"), 560);
  });
});

$("monthFilter").addEventListener("change", renderAll);

$("memberForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const id = $("memberId").value;
  const member = {
    id: id || uid(),
    name: $("memberName").value.trim(),
    phone: $("memberPhone").value.trim(),
    active: $("memberActive").value === "true"
  };
  if (id) {
    data.members = data.members.map((item) => item.id === id ? member : item);
  } else {
    data.members.push(member);
  }
  saveData();
  resetForms();
  renderAll();
});

$("mealForm").addEventListener("submit", (event) => {
  event.preventDefault();
  if (!$("mealMember").value) return alert("Please add an active member first.");
  const id = $("mealId").value;
  const meal = {
    id: id || uid(),
    date: $("mealDate").value,
    memberId: $("mealMember").value,
    breakfast: number($("mealBreakfast").value),
    lunch: number($("mealLunch").value),
    dinner: number($("mealDinner").value)
  };
  if (id) {
    data.meals = data.meals.map((item) => item.id === id ? meal : item);
  } else {
    data.meals.push(meal);
  }
  saveData();
  resetForms();
  renderAll();
});

$("expenseForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const id = $("expenseId").value;
  const expense = {
    id: id || uid(),
    date: $("expenseDate").value,
    buyer: $("expenseBuyer").value.trim(),
    item: $("expenseItem").value.trim(),
    amount: number($("expenseAmount").value),
    note: $("expenseNote").value.trim()
  };
  if (id) {
    data.expenses = data.expenses.map((item) => item.id === id ? expense : item);
  } else {
    data.expenses.push(expense);
  }
  saveData();
  resetForms();
  renderAll();
});

$("stockForm").addEventListener("submit", (event) => {
  event.preventDefault();
  data.stocks.push({
    id: uid(),
    item: $("stockItem").value.trim(),
    quantity: number($("stockQuantity").value),
    unit: $("stockUnit").value.trim(),
    price: number($("stockPrice").value),
    date: $("stockDate").value
  });
  saveData();
  resetForms();
  renderAll();
});

$("stockUseForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const item = $("useStockItem").value;
  if (!item) return alert("Please add stock first.");
  const stock = stockSummary().find((entry) => entry.item === item);
  const usedQty = number($("useStockQuantity").value);
  if (usedQty <= 0) return alert("Please enter a valid used quantity.");
  if (!stock || stock.quantity <= 0) {
    return alert(`${item} is Out of Stock.`);
  }
  if (usedQty > stock.quantity) {
    return alert(`Only ${stock.quantity.toFixed(2)} ${stock.unit || "unit"} available. You cannot use more than current stock.`);
  }
  data.stockUses.push({
    id: uid(),
    item,
    quantity: usedQty,
    date: $("useStockDate").value,
    note: $("useStockNote").value.trim()
  });
  saveData();
  $("stockUseForm").reset();
  setDefaultDates();
  renderAll();
});

$("buaForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const bill = {
    month: $("buaMonth").value,
    amount: number($("buaAmount").value),
    note: $("buaNote").value.trim()
  };
  const exists = data.buaBills.some((item) => item.month === bill.month);
  data.buaBills = exists
    ? data.buaBills.map((item) => item.month === bill.month ? bill : item)
    : [...data.buaBills, bill];
  $("monthFilter").value = bill.month;
  saveData();
  renderAll();
});

$("depositForm").addEventListener("submit", (event) => {
  event.preventDefault();
  if (!$("depositMember").value) return alert("Please add an active member first.");
  const id = $("depositId").value;
  const deposit = {
    id: id || uid(),
    date: $("depositDate").value,
    memberId: $("depositMember").value,
    amount: number($("depositAmount").value),
    note: $("depositNote").value.trim()
  };
  if (id) {
    data.deposits = data.deposits.map((item) => item.id === id ? deposit : item);
  } else {
    data.deposits.push(deposit);
  }
  saveData();
  resetForms();
  renderAll();
});

$("otherForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const id = $("otherId").value;
  const expense = {
    id: id || uid(),
    date: $("otherDate").value,
    name: $("otherName").value.trim(),
    amount: number($("otherAmount").value),
    note: $("otherNote").value.trim()
  };
  if (id) {
    data.otherExpenses = data.otherExpenses.map((item) => item.id === id ? expense : item);
  } else {
    data.otherExpenses.push(expense);
  }
  saveData();
  resetForms();
  renderAll();
});

$("printBtn").addEventListener("click", () => {
  openTab("bill");
  window.print();
});

$("exportBtn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `mess-data-${selectedMonth()}.json`;
  link.click();
  URL.revokeObjectURL(url);
});

$("importBtn").addEventListener("click", () => {
  const file = $("importFile").files[0];
  if (!file) return alert("Please choose a JSON file first.");
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      data = { ...structuredClone(defaultData), ...imported };
      saveData();
      renderAll();
      alert("Data imported successfully.");
    } catch (error) {
      alert("Invalid JSON file.");
    }
  };
  reader.readAsText(file);
});

$("resetBtn").addEventListener("click", () => {
  const sure = confirm("Are you sure you want to delete all data?");
  if (!sure) return;
  const finalSure = confirm("Last confirmation: all members, meals, expenses, stock and deposits will be deleted.");
  if (!finalSure) return;
  data = structuredClone(defaultData);
  saveData();
  renderAll();
});

async function initApp() {
  data = await loadData();
  $("monthFilter").value = currentMonth();
  setDefaultDates();
  renderAll();
}

initApp();
